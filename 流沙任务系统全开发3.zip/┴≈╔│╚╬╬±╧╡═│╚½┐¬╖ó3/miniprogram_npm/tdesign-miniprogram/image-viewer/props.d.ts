import { TdImageViewerProps } from './type';
declare const props: TdImageViewerProps;
export default props;
