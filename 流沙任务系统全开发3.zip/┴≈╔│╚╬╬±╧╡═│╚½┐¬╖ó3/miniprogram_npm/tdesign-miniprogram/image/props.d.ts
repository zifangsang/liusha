import { TdImageProps } from './type';
declare const props: TdImageProps;
export default props;
