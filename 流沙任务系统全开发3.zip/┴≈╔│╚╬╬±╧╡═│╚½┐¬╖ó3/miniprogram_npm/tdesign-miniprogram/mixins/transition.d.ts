export default function transition(): string;
