import { TdPullDownRefreshProps } from './type';
declare const props: TdPullDownRefreshProps;
export default props;
