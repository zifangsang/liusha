export default [
  {
    icon: 'home',
    text: '首页',
    url: 'pages/home/home',
  },
  {
    icon: 'foorm',
    text: '发布任务',
    url: 'pages/foorm/index',
  },
  {
    icon: 'person',
    text: '个人中心',
    url: 'pages/usercenter/index',
  },
];
